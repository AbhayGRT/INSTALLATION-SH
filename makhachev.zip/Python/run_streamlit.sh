#!/bin/bash

echo "Activating virtual environment..."
source si-deployment/bin/activate

# Kill process on port 8501 if it exists
PORT=8501
PID=$(lsof -ti :$PORT)

if [ ! -z "$PID" ]; then
    echo "Stopping existing process on port $PORT..."
    kill -9 $PID
fi

# Run Streamlit app
echo "Starting Streamlit app..."
streamlit run main.py --server.address 0.0.0.0
